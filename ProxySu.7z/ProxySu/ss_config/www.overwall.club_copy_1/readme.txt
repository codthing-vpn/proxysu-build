QR.bmp
此文件为shadowsocks（Android）、Shadowrocket(ios)扫码导入节点
-----------------------------------------

url.txt
此文件为shadowsocks（Android）、Shadowrocket(ios)复制粘贴导入节点的网址

shadowsocks（Android）下载网址：https://github.com/shadowsocks/shadowsocks-android/releases
Shadowrocket(ios)下载,需要使用国外区的AppleID。请自行谷歌方法。

-----------------------------------------

QR_pc.bmp
此文件为Shadowsocks (windows)扫码导入节点
-----------------------------------------

url_pc.txt
此文件为Shadowsocks (windows)复制粘贴导入节点的网址

Shadowsocks (windows)下载网址：https://github.com/shadowsocks/shadowsocks-windows/releases
-----------------------------------------

服务器通用连接配置参数

服务器地址(address):www.overwall.club
         端口(port):443
               密码:dana.2022
           加密方式:xchacha20-ietf-poly1305
           插件程序:v2ray-plugin
           插件选项:tls;host=www.overwall.club;path=/e054
-----------------------------------------

插件使用说明
ProxySU默认所有插件，在Shadowsocks (windows)运行文件所在文件夹的子文件夹plugins下。
电脑端手动安装插件说明
先下载插件，各个插件Windows客户端下载地址为：
Simple-obfs: https://github.com/shadowsocks/simple-obfs/releases 只下载 obfs-local.zip
V2ray-plugin: https://github.com/shadowsocks/v2ray-plugin/releases 64位系统选择：v2ray-plugin-windows-amd64-vx.x.x.tar.gz,32位系统选择：v2ray-plugin-windows-386-vx.x.x.tar.gz (x为数字，是版本号)
Kcptun-plugin: https://github.com/shadowsocks/kcptun/releases 64位系统选择：kcptun-windows-amd64-xxxxxx.tar.gz,32位系统选择：kcptun-plugin-windows-386-xxxxxx.tar.gz (x为数字，是版本号)
在Shadowsocks (windows)运行文件所在文件夹中，新建文件夹plugins，将obfs-local.zip解压出的文件（两个）全部复制到plugins中，v2ray -plugin下载得到的文件，解压出的文件，复制到plugins中，并重命名为：v2ray-plugin.exe。Kcptun -plugin下载得到的文件，解压出两个文件，将其中的client_windows开头的文件，复制到plugins中，并重命名为：kcptun-client.exe。GoQuiet-plugin下载得到的文件，直接复制到plugin中，并重命名为：goquiet-client.exe。Cloak-plugin下载得到的文件，直接复制到plugin中，并重命名为：cloak-client.exe
安装完毕
-----------------------------------------

手机安卓客户端插件安装说明
先下载插件，各个插件安卓客户端下载地址为：
Simple-obfs: https://github.com/shadowsocks/simple-obfs-android/releases 只下载 obfs-local-nightly-x.x.x.apk(x为数字，是版本号)
V2ray-plugin: https://github.com/shadowsocks/v2ray-plugin-android/releases 一般选择v2ray--universal-x.x.x.apk(x为数字，是版本号)
Kcptun-plugin: https://github.com/shadowsocks/kcptun-android/releases 一般选择kcptun--universal-x.x.x.apk(x为数字，是版本号)
将上述apk文件传到手机，安装即可！
